# Store Rating System

Beginner-friendly full-stack coding challenge starter:
- Frontend: React + Vite
- Backend: Express.js
- Database: MySQL

## Folder guide
- `frontend/src/App.jsx`: screens and role-based navigation
- `frontend/src/App.css`: styles
- `frontend/src/main.jsx`: React entry point
- `backend/server.js`: Express API
- `backend/database.js`: MySQL connection
- `backend/routes/`: API endpoints
- `database/schema.sql`: tables and demo seed instructions

## One-time setup
1. Install Node.js LTS, VS Code, and MySQL Server. MySQL Workbench is a visual tool for managing the database.
2. In MySQL Workbench, open `database/schema.sql` and execute it. This creates the database and tables.
3. Open the `backend` folder in VS Code's integrated terminal and run: `npm install`
4. Copy `backend/.env.example` to `backend/.env` and enter your own MySQL password.
5. In the backend terminal run: `npm run dev`
6. Open a second VS Code terminal, go to `frontend`, and run: `npm install`, then `npm run dev`
7. Open the local URL Vite shows in your browser.

These are setup/runtime commands; a React/Express app cannot run just by creating folders. You can create/edit all source files through VS Code Explorer without command-line file creation.

## First admin account
Public signup intentionally creates only a Normal User. For a real deployment, create the first administrator through a controlled seed script or manually in MySQL with a securely hashed password. Do not make public signup accept the admin role.
