import React, { useEffect, useState } from "react";

const API = "http://localhost:5000/api";
const readSession = () => {
  try { return { token: localStorage.getItem("token"), user: JSON.parse(localStorage.getItem("user") || "null") }; }
  catch { return { token: null, user: null }; }
};

async function request(path, token, options = {}) {
  const response = await fetch(`${API}${path}`, {
    ...options,
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}), ...(options.headers || {}) }
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || "Request failed.");
  return data;
}

function Field({ label, value, onChange, type = "text", required = true, minLength, maxLength }) {
  return <label className="field">{label}<input value={value} onChange={e => onChange(e.target.value)} type={type} required={required} minLength={minLength} maxLength={maxLength} /></label>;
}

function Auth({ onLogin, showMessage }) {
  const [mode, setMode] = useState("login");
  const [form, setForm] = useState({ name: "", email: "", address: "", password: "" });
  const change = key => value => setForm(old => ({ ...old, [key]: value }));
  async function submit(e) {
    e.preventDefault();
    try {
      if (mode === "signup") {
        await request("/auth/signup", null, { method: "POST", body: JSON.stringify(form) });
        showMessage("Account created. Please log in.");
        setMode("login");
      } else {
        const data = await request("/auth/login", null, { method: "POST", body: JSON.stringify({ email: form.email, password: form.password }) });
        localStorage.setItem("token", data.token);
        localStorage.setItem("user", JSON.stringify(data.user));
        onLogin(data);
      }
    } catch (error) { showMessage(error.message, true); }
  }
  return <div className="auth-wrap"><form className="panel auth-panel" onSubmit={submit}>
    <div className="brand-mark">SR</div><p className="eyebrow">STORE RATING PLATFORM</p>
    <h1>{mode === "login" ? "Welcome back" : "Create your account"}</h1>
    <p className="muted">Sign in to discover stores and share your experience.</p>
    {mode === "signup" && <>
      <Field label="Full name (20–60 characters)" value={form.name} onChange={change("name")} minLength={20} maxLength={60} />
      <Field label="Address" value={form.address} onChange={change("address")} maxLength={400} />
    </>}
    <Field label="Email address" value={form.email} onChange={change("email")} type="email" />
    <Field label="Password" value={form.password} onChange={change("password")} type="password" minLength={8} maxLength={16} />
    {mode === "signup" && <p className="hint">Use 8–16 characters, including an uppercase letter and a special character.</p>}
    <button className="primary full" type="submit">{mode === "login" ? "Sign in" : "Create account"}</button>
    <button className="link-button" type="button" onClick={() => setMode(mode === "login" ? "signup" : "login")}>{mode === "login" ? "New here? Create an account" : "Already registered? Sign in"}</button>
  </form></div>;
}

function App() {
  const [session, setSession] = useState(readSession);
  const [message, setMessage] = useState("");
  const [isError, setIsError] = useState(false);
  const [stores, setStores] = useState([]);
  const [search, setSearch] = useState("");
  const [dashboard, setDashboard] = useState(null);
  const [users, setUsers] = useState([]);
  const [ownerSummary, setOwnerSummary] = useState(null);
  const [newStore, setNewStore] = useState({ name: "", email: "", address: "" });
  const [newUser, setNewUser] = useState({ name: "", email: "", password: "", address: "", role: "USER" });

  function showMessage(text, error = false) { setMessage(text); setIsError(error); }
  function logout() {
    localStorage.removeItem("token"); localStorage.removeItem("user");
    setSession({ token: null, user: null }); setStores([]); setDashboard(null);
  }
  async function load() {
    if (!session.token || !session.user) return;
    try {
      if (session.user.role === "ADMIN") {
        const [stats, storeList, userList] = await Promise.all([
          request("/admin/dashboard", session.token),
          request("/admin/stores", session.token),
          request("/admin/users", session.token)
        ]);
        setDashboard(stats); setStores(storeList); setUsers(userList);
      } else if (session.user.role === "OWNER") {
        setOwnerSummary(await request("/ratings/owner/summary", session.token));
      } else {
        setStores(await request(`/stores?search=${encodeURIComponent(search)}`, session.token));
      }
    } catch (error) { showMessage(error.message, true); }
  }
  useEffect(() => { load(); }, [session.token, session.user?.role, search]);

  async function rate(storeId, score) {
    try { await request(`/ratings/${storeId}`, session.token, { method: "PUT", body: JSON.stringify({ score: Number(score) }) }); showMessage("Your rating has been saved."); await load(); }
    catch (error) { showMessage(error.message, true); }
  }
  async function addStore(e) {
    e.preventDefault();
    try {
      await request("/stores", session.token, { method: "POST", body: JSON.stringify(newStore) });
      setNewStore({ name: "", email: "", address: "" }); showMessage("Store added."); await load();
    } catch (error) { showMessage(error.message, true); }
  }
  async function addUser(e) {
    e.preventDefault();
    try {
      await request("/admin/users", session.token, { method: "POST", body: JSON.stringify(newUser) });
      setNewUser({ name: "", email: "", password: "", address: "", role: "USER" }); showMessage("User created."); await load();
    } catch (error) { showMessage(error.message, true); }
  }
  if (!session.user || !session.token) return <><Auth onLogin={data => setSession({ token: data.token, user: data.user })} showMessage={showMessage} />{message && <div className={`toast ${isError ? "error" : ""}`}>{message}</div>}</>;

  const user = session.user;
  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><span className="brand-mark small">SR</span><span>StoreRate<small>Ratings made useful</small></span></div>
      <p className="nav-label">WORKSPACE</p>
      <div className="nav-item active">▦ <span>{user.role === "ADMIN" ? "Admin dashboard" : user.role === "OWNER" ? "Owner dashboard" : "Explore stores"}</span></div>
      <div className="sidebar-bottom"><div className="avatar">{user.name.slice(0, 1).toUpperCase()}</div><div className="profile"><strong>{user.name}</strong><small>{user.role}</small></div><button className="logout" onClick={logout} title="Log out">↗</button></div>
    </aside>
    <main className="main-content">
      <header className="topbar"><div><p className="eyebrow">YOUR WORKSPACE</p><h1>{user.role === "ADMIN" ? "Overview" : user.role === "OWNER" ? "Store performance" : "Find your next favorite"}</h1></div><div className="user-pill"><span className="online-dot"></span>{user.email}</div></header>
      {message && <div className={`notice ${isError ? "error" : ""}`}>{message}<button onClick={() => setMessage("")}>×</button></div>}
      {user.role === "ADMIN" && <>
        <section className="stats-grid">
          {[["Total users", dashboard?.totalUsers ?? "—", "♙"], ["Registered stores", dashboard?.totalStores ?? "—", "⌂"], ["Ratings submitted", dashboard?.totalRatings ?? "—", "★"]].map(([label, value, icon]) => <div className="stat-card" key={label}><div className="stat-icon">{icon}</div><p>{label}</p><strong>{value}</strong></div>)}
        </section>
        <section className="panel"><div className="section-heading"><div><p className="eyebrow">MANAGEMENT</p><h2>Add a store</h2></div></div>
          <form className="form-grid" onSubmit={addStore}><Field label="Store name" value={newStore.name} onChange={v => setNewStore({ ...newStore, name: v })} /><Field label="Store email" value={newStore.email} onChange={v => setNewStore({ ...newStore, email: v })} type="email" /><Field label="Address" value={newStore.address} onChange={v => setNewStore({ ...newStore, address: v })} maxLength={400} /><button className="primary" type="submit">Add store</button></form>
        </section>
        <section className="panel"><div className="section-heading"><div><p className="eyebrow">PEOPLE</p><h2>Create a user</h2></div></div>
          <form className="form-grid" onSubmit={addUser}><Field label="Name (20–60 characters)" value={newUser.name} onChange={v => setNewUser({ ...newUser, name: v })} minLength={20} maxLength={60} /><Field label="Email" value={newUser.email} onChange={v => setNewUser({ ...newUser, email: v })} type="email" /><Field label="Temporary password" value={newUser.password} onChange={v => setNewUser({ ...newUser, password: v })} type="password" minLength={8} maxLength={16} /><Field label="Address" value={newUser.address} onChange={v => setNewUser({ ...newUser, address: v })} maxLength={400} /><label className="field">Role<select value={newUser.role} onChange={e => setNewUser({ ...newUser, role: e.target.value })}><option value="USER">Normal User</option><option value="ADMIN">Administrator</option><option value="OWNER">Store Owner</option></select></label><button className="primary" type="submit">Create user</button></form>
        </section>
        <section className="panel"><div className="section-heading"><div><p className="eyebrow">DIRECTORY</p><h2>Stores</h2></div></div><StoreTable stores={stores} /></section>
        <section className="panel"><div className="section-heading"><div><p className="eyebrow">DIRECTORY</p><h2>Users</h2></div></div><div className="table-wrap"><table><thead><tr><th>Name</th><th>Email</th><th>Address</th><th>Role</th><th>Owner rating</th></tr></thead><tbody>{users.map(u => <tr key={u.id}><td>{u.name}</td><td>{u.email}</td><td>{u.address}</td><td><span className="role-chip">{u.role}</span></td><td>{u.ownerRating ?? "—"}</td></tr>)}</tbody></table></div></section>
      </>}
      {user.role === "USER" && <>
        <div className="search-row"><div><h2>Stores around you</h2><p className="muted">Browse stores and share a rating from 1 to 5.</p></div><input className="search-input" placeholder="Search name or address..." value={search} onChange={e => setSearch(e.target.value)} /></div>
        <section className="store-grid">{stores.map(store => <article className="store-card" key={store.id}><div className="store-art">⌂</div><div className="store-card-body"><span className="category-tag">REGISTERED STORE</span><h3>{store.name}</h3><p className="muted">{store.address}</p><div className="rating-summary"><span>★ {store.overallRating ?? "No ratings yet"}</span><span className="muted">Your rating: {store.myRating ?? "Not rated"}</span></div><label className="field">Your rating<select value={store.myRating ?? ""} onChange={e => e.target.value && rate(store.id, e.target.value)}><option value="">Choose 1–5 stars</option>{[1, 2, 3, 4, 5].map(n => <option key={n} value={n}>{n} {n === 1 ? "star" : "stars"}</option>)}</select></label><button className="primary full" onClick={() => showMessage("Choose a rating above to submit or update it.")}>{store.myRating ? "Update rating above" : "Submit rating above"}</button></div></article>)}</section>
      </>}
      {user.role === "OWNER" && <>
        <section className="panel"><div className="section-heading"><div><p className="eyebrow">YOUR STORES</p><h2>Average ratings</h2></div></div><div className="stats-grid">{(ownerSummary?.stores || []).map(s => <div className="stat-card" key={s.id}><p>{s.name}</p><strong>★ {s.averageRating ?? "—"}</strong><p>{s.ratingCount} ratings</p></div>)}</div></section>
        <section className="panel"><div className="section-heading"><div><p className="eyebrow">CUSTOMER FEEDBACK</p><h2>Submitted ratings</h2></div></div><div className="table-wrap"><table><thead><tr><th>Store</th><th>User</th><th>Email</th><th>Rating</th><th>Updated</th></tr></thead><tbody>{(ownerSummary?.ratings || []).map((r, i) => <tr key={i}><td>{r.storeName}</td><td>{r.userName}</td><td>{r.email}</td><td>★ {r.score}</td><td>{new Date(r.updated_at).toLocaleDateString()}</td></tr>)}</tbody></table></div></section>
      </>}
    </main>
  </div>;
}

function StoreTable({ stores }) {
  const [sort, setSort] = useState({ key: "name", dir: 1 });
  const sorted = [...stores].sort((a, b) => String(a[sort.key] ?? "").localeCompare(String(b[sort.key] ?? "")) * sort.dir);
  const heading = (label, key) => <th><button className="sort-button" onClick={() => setSort(old => ({ key, dir: old.key === key ? -old.dir : 1 }))}>{label} ↕</button></th>;
  return <div className="table-wrap"><table><thead><tr>{heading("Name", "name")}{heading("Email", "email")}{heading("Address", "address")}{heading("Rating", "rating")}</tr></thead><tbody>{sorted.map(s => <tr key={s.id}><td>{s.name}</td><td>{s.email}</td><td>{s.address}</td><td>{s.rating ?? "—"}</td></tr>)}</tbody></table></div>;
}
export default App;
