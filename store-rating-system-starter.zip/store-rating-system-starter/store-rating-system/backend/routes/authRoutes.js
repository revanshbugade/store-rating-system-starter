import { Router } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import pool from "../database.js";
import { requireAuth } from "../middleware/authMiddleware.js";

const router = Router();
const validEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const validPassword = /^(?=.*[A-Z])(?=.*[^A-Za-z0-9]).{8,16}$/;

router.post("/signup", async (req, res, next) => {
  try {
    const { name, email, address, password } = req.body;
    if (!name || name.length < 20 || name.length > 60)
      return res.status(400).json({ message: "Name must be 20–60 characters." });
    if (!address || address.length > 400)
      return res.status(400).json({ message: "Address is required and must be at most 400 characters." });
    if (!validEmail.test(email || ""))
      return res.status(400).json({ message: "Enter a valid email address." });
    if (!validPassword.test(password || ""))
      return res.status(400).json({ message: "Password must be 8–16 characters and include an uppercase letter and a special character." });

    const [existing] = await pool.execute("SELECT id FROM users WHERE email = ?", [email]);
    if (existing.length) return res.status(409).json({ message: "That email is already registered." });

    const passwordHash = await bcrypt.hash(password, 12);
    const [result] = await pool.execute(
      "INSERT INTO users (name, email, password_hash, address, role) VALUES (?, ?, ?, ?, 'USER')",
      [name.trim(), email.toLowerCase().trim(), passwordHash, address.trim()]
    );
    res.status(201).json({ message: "Account created. You can now log in.", id: result.insertId });
  } catch (error) { next(error); }
});

router.post("/login", async (req, res, next) => {
  try {
    const { email, password } = req.body;
    const [rows] = await pool.execute(
      "SELECT id, name, email, password_hash, address, role FROM users WHERE email = ?",
      [(email || "").toLowerCase().trim()]
    );
    const user = rows[0];
    if (!user || !(await bcrypt.compare(password || "", user.password_hash)))
      return res.status(401).json({ message: "Invalid email or password." });

    const token = jwt.sign(
      { id: user.id, name: user.name, email: user.email, role: user.role },
      process.env.JWT_SECRET, { expiresIn: "8h" }
    );
    res.json({ token, user: { id: user.id, name: user.name, email: user.email, address: user.address, role: user.role } });
  } catch (error) { next(error); }
});

router.put("/password", requireAuth, async (req, res, next) => {
  try {
    const { currentPassword, newPassword } = req.body;
    if (!/^(?=.*[A-Z])(?=.*[^A-Za-z0-9]).{8,16}$/.test(newPassword || ""))
      return res.status(400).json({ message: "New password must be 8–16 characters and include an uppercase letter and special character." });
    const [rows] = await pool.execute("SELECT password_hash FROM users WHERE id = ?", [req.user.id]);
    if (!rows[0] || !(await bcrypt.compare(currentPassword || "", rows[0].password_hash)))
      return res.status(400).json({ message: "Current password is incorrect." });
    const hash = await bcrypt.hash(newPassword, 12);
    await pool.execute("UPDATE users SET password_hash = ? WHERE id = ?", [hash, req.user.id]);
    res.json({ message: "Password updated successfully." });
  } catch (error) { next(error); }
});

export default router;
