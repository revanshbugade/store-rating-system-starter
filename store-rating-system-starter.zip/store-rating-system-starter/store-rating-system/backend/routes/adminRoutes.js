import { Router } from "express";
import bcrypt from "bcryptjs";
import pool from "../database.js";
import { requireAuth, allowRoles } from "../middleware/authMiddleware.js";

const router = Router();
router.use(requireAuth, allowRoles("ADMIN"));

router.get("/dashboard", async (req, res, next) => {
  try {
    const [[users]] = await pool.query("SELECT COUNT(*) AS totalUsers FROM users");
    const [[stores]] = await pool.query("SELECT COUNT(*) AS totalStores FROM stores");
    const [[ratings]] = await pool.query("SELECT COUNT(*) AS totalRatings FROM ratings");
    res.json({ totalUsers: users.totalUsers, totalStores: stores.totalStores, totalRatings: ratings.totalRatings });
  } catch (error) { next(error); }
});

router.get("/users", async (req, res, next) => {
  try {
    const search = `%${(req.query.search || "").trim()}%`;
    const [rows] = await pool.execute(`
      SELECT u.id, u.name, u.email, u.address, u.role,
      CASE WHEN u.role = 'OWNER' THEN (
        SELECT ROUND(AVG(r.score), 2) FROM stores s LEFT JOIN ratings r ON r.store_id=s.id
        WHERE s.owner_id=u.id
      ) ELSE NULL END AS ownerRating
      FROM users u
      WHERE u.name LIKE ? OR u.email LIKE ? OR u.address LIKE ? OR u.role LIKE ?
      ORDER BY u.name ASC`, [search, search, search, search]);
    res.json(rows);
  } catch (error) { next(error); }
});

router.post("/users", async (req, res, next) => {
  try {
    const { name, email, password, address, role } = req.body;
    if (!name || name.length < 20 || name.length > 60)
      return res.status(400).json({ message: "Name must be 20–60 characters." });
    if (!address || address.length > 400)
      return res.status(400).json({ message: "Address is required and at most 400 characters." });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email || ""))
      return res.status(400).json({ message: "Enter a valid email." });
    if (!/^(?=.*[A-Z])(?=.*[^A-Za-z0-9]).{8,16}$/.test(password || ""))
      return res.status(400).json({ message: "Password must be 8–16 characters with an uppercase letter and special character." });
    if (!["ADMIN", "USER", "OWNER"].includes(role))
      return res.status(400).json({ message: "Choose a valid role." });
    const hash = await bcrypt.hash(password, 12);
    const [result] = await pool.execute(
      "INSERT INTO users (name, email, password_hash, address, role) VALUES (?, ?, ?, ?, ?)",
      [name.trim(), email.toLowerCase().trim(), hash, address.trim(), role]
    );
    res.status(201).json({ id: result.insertId, message: "User created." });
  } catch (error) {
    if (error.code === "ER_DUP_ENTRY") return res.status(409).json({ message: "Email already exists." });
    next(error);
  }
});

router.get("/stores", async (req, res, next) => {
  try {
    const search = `%${(req.query.search || "").trim()}%`;
    const [rows] = await pool.execute(`
      SELECT s.id, s.name, s.email, s.address, ROUND(AVG(r.score), 2) AS rating
      FROM stores s LEFT JOIN ratings r ON r.store_id=s.id
      WHERE s.name LIKE ? OR s.email LIKE ? OR s.address LIKE ?
      GROUP BY s.id ORDER BY s.name ASC`, [search, search, search]);
    res.json(rows);
  } catch (error) { next(error); }
});

export default router;
