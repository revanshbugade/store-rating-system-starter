import { Router } from "express";
import pool from "../database.js";
import { requireAuth, allowRoles } from "../middleware/authMiddleware.js";

const router = Router();

router.get("/", requireAuth, async (req, res, next) => {
  try {
    const search = `%${(req.query.search || "").trim()}%`;
    const [stores] = await pool.execute(`
      SELECT s.id, s.name, s.email, s.address,
        ROUND(AVG(r.score), 2) AS overallRating,
        MAX(CASE WHEN r.user_id = ? THEN r.score END) AS myRating
      FROM stores s
      LEFT JOIN ratings r ON r.store_id = s.id
      WHERE s.name LIKE ? OR s.address LIKE ?
      GROUP BY s.id
      ORDER BY s.name ASC`, [req.user.id, search, search]);
    res.json(stores);
  } catch (error) { next(error); }
});

router.post("/", requireAuth, allowRoles("ADMIN"), async (req, res, next) => {
  try {
    const { name, email, address, ownerId } = req.body;
    if (!name?.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email || "") || !address?.trim() || address.length > 400)
      return res.status(400).json({ message: "Enter a store name, valid email, and address up to 400 characters." });
    const [result] = await pool.execute(
      "INSERT INTO stores (name, email, address, owner_id) VALUES (?, ?, ?, ?)",
      [name.trim(), email.trim().toLowerCase(), address.trim(), ownerId || null]
    );
    res.status(201).json({ message: "Store created.", id: result.insertId });
  } catch (error) { next(error); }
});

export default router;
