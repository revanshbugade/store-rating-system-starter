import { Router } from "express";
import pool from "../database.js";
import { requireAuth, allowRoles } from "../middleware/authMiddleware.js";

const router = Router();

router.put("/:storeId", requireAuth, allowRoles("USER"), async (req, res, next) => {
  try {
    const score = Number(req.body.score);
    const storeId = Number(req.params.storeId);
    if (!Number.isInteger(score) || score < 1 || score > 5)
      return res.status(400).json({ message: "Rating must be a whole number from 1 to 5." });
    const [stores] = await pool.execute("SELECT id FROM stores WHERE id = ?", [storeId]);
    if (!stores.length) return res.status(404).json({ message: "Store not found." });

    await pool.execute(
      `INSERT INTO ratings (user_id, store_id, score) VALUES (?, ?, ?)
       ON DUPLICATE KEY UPDATE score = VALUES(score), updated_at = CURRENT_TIMESTAMP`,
      [req.user.id, storeId, score]
    );
    res.json({ message: "Rating saved successfully." });
  } catch (error) { next(error); }
});

router.get("/owner/summary", requireAuth, allowRoles("OWNER"), async (req, res, next) => {
  try {
    const [stores] = await pool.execute(`
      SELECT s.id, s.name, ROUND(AVG(r.score), 2) AS averageRating, COUNT(r.id) AS ratingCount
      FROM stores s LEFT JOIN ratings r ON r.store_id = s.id
      WHERE s.owner_id = ? GROUP BY s.id ORDER BY s.name`, [req.user.id]);
    const [ratings] = await pool.execute(`
      SELECT s.name AS storeName, u.name AS userName, u.email, r.score, r.updated_at
      FROM ratings r JOIN stores s ON s.id = r.store_id JOIN users u ON u.id = r.user_id
      WHERE s.owner_id = ? ORDER BY r.updated_at DESC`, [req.user.id]);
    res.json({ stores, ratings });
  } catch (error) { next(error); }
});

export default router;
