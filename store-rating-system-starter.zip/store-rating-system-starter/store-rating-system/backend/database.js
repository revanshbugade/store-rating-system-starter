import mysql from "mysql2/promise";
import dotenv from "dotenv";
dotenv.config();

const pool = mysql.createPool({
  host: process.env.DB_HOST || "127.0.0.1",
  port: Number(process.env.DB_PORT) || 3306,
  user: process.env.DB_USER || "storeapp",
  password: process.env.DB_PASSWORD || "StoreApp123!",
  database: process.env.DB_NAME || "store_rating_system",
  waitForConnections: true,
  connectionLimit: 10
});

export default pool;
